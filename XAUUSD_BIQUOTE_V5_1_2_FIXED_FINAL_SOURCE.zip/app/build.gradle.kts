plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.xauusd.scalper"; compileSdk = 35
    defaultConfig { applicationId = "com.xauusd.scalper"; minSdk = 26; targetSdk = 35; versionCode = 13; versionName = "5.1.2-FIXED-FINAL" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
