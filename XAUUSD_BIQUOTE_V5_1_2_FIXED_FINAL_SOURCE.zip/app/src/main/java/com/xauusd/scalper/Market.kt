package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object Market {
    private const val BASE="https://biquote.io/api"
    private const val SYMBOL="XAUUSD"
    private fun get(url:String):String {
        val c=URL(url).openConnection() as HttpURLConnection
        c.connectTimeout=12000; c.readTimeout=12000; c.requestMethod="GET"
        return try { val code=c.responseCode; val s=if(code in 200..299)c.inputStream else c.errorStream; val body=s?.bufferedReader()?.use{it.readText()}.orEmpty(); if(code !in 200..299) throw Exception("BIQUOTE HTTP $code"); body } finally { c.disconnect() }
    }
    fun price():Double { val j=JSONObject(get("$BASE/$SYMBOL")); val p=j.optDouble("mid",Double.NaN); if(p.isNaN()||p<=0)throw Exception("XAUUSD price unavailable"); return p }
    fun candles(interval:String,limit:Int):List<Candle>{
        val a=JSONObject(get("$BASE/$SYMBOL/ohlc?interval=$interval&limit=$limit")).optJSONArray("bars") ?: throw Exception("No $interval candles")
        val out=ArrayList<Candle>(); for(i in 0 until a.length()){val b=a.optJSONObject(i)?:continue; val o=b.optDouble("open",Double.NaN);val h=b.optDouble("high",Double.NaN);val l=b.optDouble("low",Double.NaN);val c=b.optDouble("close",Double.NaN);if(o.isNaN()||h.isNaN()||l.isNaN()||c.isNaN())continue;out.add(Candle(b.optString("openTime"),o,h,l,c))}; if(out.size<30)throw Exception("Not enough $interval candles"); return out
    }
}
