package com.xauusd.scalper
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
object Telegram { fun send(token:String,chat:String,msg:String):Boolean=try{val c=URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection;val body="chat_id=${URLEncoder.encode(chat,"UTF-8")}&text=${URLEncoder.encode(msg,"UTF-8")}";c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");c.outputStream.use{it.write(body.toByteArray())};c.responseCode in 200..299}catch(_:Exception){false} }
