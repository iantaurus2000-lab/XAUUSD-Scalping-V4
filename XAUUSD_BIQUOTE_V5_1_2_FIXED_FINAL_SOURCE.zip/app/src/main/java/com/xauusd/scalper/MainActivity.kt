package com.xauusd.scalper

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity:Activity(){
 private lateinit var price:TextView;private lateinit var status:TextView;private lateinit var bias:TextView;private lateinit var signal:TextView;private lateinit var detail:TextView
 private val sp by lazy{getSharedPreferences("settings",0)}
 private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){i?:return;val p=i.getDoubleExtra("price",Double.NaN);if(!p.isNaN())price.text="XAUUSD  %.2f".format(p);status.text=i.getStringExtra("msg")?:"LIVE";if(status.text.startsWith("M5 "))bias.text=status.text;signal.text=if(status.text.contains("BOS"))"SIGNAL: SETUP DETECTED" else "SIGNAL: WAIT";detail.text="M1 wick-tip entry • Liquidity Sweep • Wick Rejection • BOS"}}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);price=findViewById(R.id.price);status=findViewById(R.id.status);bias=findViewById(R.id.bias);signal=findViewById(R.id.signal);detail=findViewById(R.id.detail);findViewById<Button>(R.id.start).setOnClickListener{startBot()};findViewById<Button>(R.id.test).setOnClickListener{testAlarm()};if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10);startBot()}
 override fun onResume(){super.onResume();ContextCompat.registerReceiver(this,receiver,IntentFilter(SignalService.ACTION),ContextCompat.RECEIVER_NOT_EXPORTED)}
 override fun onPause(){try{unregisterReceiver(receiver)}catch(_:Exception){};super.onPause()}
 private fun startBot(){ContextCompat.startForegroundService(this,Intent(this,SignalService::class.java));status.text="LIVE • BIQUOTE"}
 private fun testAlarm(){if(Build.VERSION.SDK_INT>=26){val n=getSystemService(NotificationManager::class.java);n.createNotificationChannel(NotificationChannel("test","XAUUSD Test",NotificationManager.IMPORTANCE_HIGH));n.notify(77,androidx.core.app.NotificationCompat.Builder(this,"test").setSmallIcon(R.drawable.ic_xau_logo).setContentTitle("XAUUSD SIGNAL TEST").setContentText("Alarm aktif").setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build())}}
}
