package com.xauusd.scalper

data class Candle(val time:String,val open:Double,val high:Double,val low:Double,val close:Double)
data class Signal(val side:String,val entry:Double,val sl:Double,val tp1:Double,val tp2:Double,val confidence:Int,val time:String)
