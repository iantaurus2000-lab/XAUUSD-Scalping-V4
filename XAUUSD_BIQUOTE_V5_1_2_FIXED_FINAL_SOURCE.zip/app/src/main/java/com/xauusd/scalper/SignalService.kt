package com.xauusd.scalper

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class SignalService:Service(){
 private val handler=Handler(Looper.getMainLooper()); private var lastKey=""
 private val task=object:Runnable{override fun run(){Thread{try{val p=Market.price();val m1=Market.candles("1m",120);val m5=Market.candles("5m",80);val r=SignalEngine.evaluate(m1,m5,p);sendUpdate(p,r.second);if(r.first!=null){val s=r.first!!;val key=s.side+s.time;if(key!=lastKey){lastKey=key;alarm(s);val sp=getSharedPreferences("settings",0);val t=sp.getString("token","")?:"";val c=sp.getString("chat","")?:"";if(t.isNotBlank()&&c.isNotBlank())Telegram.send(t,c,"🟢 XAUUSD SCALPING\n\n${s.side}\nEntry: %.2f\nSL: %.2f\nTP1: %.2f\nTP2: %.2f\n\nTF: M1\nBias: M5 ${s.side}\nSetup: Liquidity Sweep + Wick Rejection + BOS\nConfidence: ${s.confidence}/5".format(s.entry,s.sl,s.tp1,s.tp2))}}}catch(e:Exception){sendUpdate(Double.NaN,"ERROR: ${e.message}")}}.start();handler.postDelayed(this,15000)}}
 override fun onCreate(){super.onCreate();channels();startForeground(8,NotificationCompat.Builder(this,"service").setSmallIcon(com.xauusd.scalper.R.drawable.ic_xau_logo).setContentTitle("XAUUSD BIQUOTE SCALPER").setContentText("Signal engine aktif").setOngoing(true).build())}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{val sp=getSharedPreferences("settings",0);if(i?.hasExtra("token")==true)sp.edit().putString("token",i.getStringExtra("token")?:"").putString("chat",i.getStringExtra("chat")?:"").apply();handler.removeCallbacks(task);handler.post(task);return START_STICKY}
 private fun channels(){if(Build.VERSION.SDK_INT>=26){val n=getSystemService(NotificationManager::class.java);n.createNotificationChannel(NotificationChannel("service","XAUUSD Service",NotificationManager.IMPORTANCE_LOW));val a=NotificationChannel("signal","XAUUSD Signal Alarm",NotificationManager.IMPORTANCE_HIGH);a.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_HIGH).build());a.enableVibration(true);n.createNotificationChannel(a)}}
 private fun alarm(s:Signal){val n=NotificationCompat.Builder(this,"signal").setSmallIcon(R.drawable.ic_xau_logo).setContentTitle("XAUUSD ${s.side}").setContentText("Entry %.2f • SL %.2f • TP1 %.2f".format(s.entry,s.sl,s.tp1)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();getSystemService(NotificationManager::class.java).notify(1001,n)}
 private fun sendUpdate(p:Double,msg:String){sendBroadcast(Intent(ACTION).setPackage(packageName).putExtra("price",p).putExtra("msg",msg))}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy()}
 override fun onBind(i:Intent?)=null
 companion object{const val ACTION="com.xauusd.scalper.UPDATE"}
}
