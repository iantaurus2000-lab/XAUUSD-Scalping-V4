package com.xauusd.scalper

import kotlin.math.abs

object SignalEngine {
    private fun ema(x:List<Double>,p:Int):Double{ if(x.size<p)return x.last(); var e=x.take(p).average(); val a=2.0/(p+1); for(i in p until x.size)e=a*x[i]+(1-a)*e; return e }
    private fun atr(c:List<Candle>):Double{ if(c.size<15)return 0.5; var s=0.0; for(i in c.size-14 until c.size)s+=c[i].high-c[i].low; return s/14.0 }
    fun evaluate(m1:List<Candle>,m5:List<Candle>,price:Double):Pair<Signal?,String>{
        if(m1.size<20||m5.size<50)return null to "WAIT: data belum cukup"
        val e20=ema(m5.map{it.close},20);val e50=ema(m5.map{it.close},50);val bias=when{m5.last().close>e20&&e20>e50->"BUY";m5.last().close<e20&&e20<e50->"SELL";else->"NEUTRAL"}
        val s=m1[m1.lastIndex-2];val confirm=m1[m1.lastIndex-1];val prior=m1.subList((m1.size-12).coerceAtLeast(0),m1.lastIndex-2);val ph=prior.maxOf{it.high};val pl=prior.minOf{it.low};val body=abs(s.close-s.open);val lw=minOf(s.open,s.close)-s.low;val uw=s.high-maxOf(s.open,s.close);val a=atr(m1)
        val buy=bias=="BUY"&&lw>=maxOf(body*1.5,a*.2)&&s.low<pl&&s.close>pl&&confirm.close>s.high
        val sell=bias=="SELL"&&uw>=maxOf(body*1.5,a*.2)&&s.high>ph&&s.close<ph&&confirm.close<s.low
        if(!buy&&!sell)return null to "M5 $bias • Wick/Sweep/BOS menunggu"
        val side=if(buy)"BUY" else "SELL";val entry=if(buy)s.low else s.high;val risk=maxOf(a*.8,.5);val sl=if(buy)entry-risk else entry+risk;val tp1=if(buy)entry+risk else entry-risk;val tp2=if(buy)entry+risk*1.8 else entry-risk*1.8;val near=abs(price-entry)<=a*.35
        return Signal(side,entry,sl,tp1,tp2,5,confirm.time) to "M5 $bias • Liquidity Sweep + Wick Rejection + BOS • ${if(near)"ENTRY CONFIRMED" else "ENTRY READY"}"
    }
}
