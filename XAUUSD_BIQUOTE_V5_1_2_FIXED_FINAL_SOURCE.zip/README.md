XAUUSD BIQUOTE V5.1.2 FIXED FINAL
Fresh Android project. Use workflow: XAUUSD BIQUOTE V5.1.2 FIXED FINAL.
No old workflow or source ZIP is required.
