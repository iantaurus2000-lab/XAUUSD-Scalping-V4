package com.xauusd.scalper

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max
import kotlin.math.min

class CandleChartView(context: Context) : View(context) {
    private var candles: List<Candle> = emptyList()
    private var timeframe = "M1"
    private var currentPrice: Double? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setData(data: List<Candle>, tf: String) {
        candles = data.takeLast(60)
        timeframe = tf
        currentPrice = candles.lastOrNull()?.close
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(16, 19, 24))
        if (candles.isEmpty()) {
            paint.color = Color.LTGRAY
            paint.textSize = 38f
            canvas.drawText("Memuat chart...", 32f, height / 2f, paint)
            return
        }

        val left = 28f
        val right = width - 92f
        val top = 44f
        val bottom = height - 46f
        val chartW = max(1f, right - left)
        val chartH = max(1f, bottom - top)
        val hi = candles.maxOf { it.high }
        val lo = candles.minOf { it.low }
        val pad = max((hi - lo) * 0.08, 0.5)
        val maxP = hi + pad
        val minP = lo - pad
        val range = maxP - minP

        fun y(p: Double): Float = (bottom - ((p - minP) / range * chartH)).toFloat()

        paint.strokeWidth = 1f
        paint.color = Color.rgb(55, 61, 70)
        for (i in 0..5) {
            val gy = top + chartH * i / 5f
            canvas.drawLine(left, gy, right, gy, paint)
            val pv = maxP - range * i / 5.0
            paint.color = Color.rgb(180, 185, 192)
            paint.textSize = 22f
            canvas.drawText(String.format("%.2f", pv), right + 8f, gy + 7f, paint)
            paint.color = Color.rgb(55, 61, 70)
        }

        paint.color = Color.WHITE
        paint.textSize = 28f
        paint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("XAU/USD  $timeframe", left, 30f, paint)
        paint.typeface = Typeface.DEFAULT

        val step = chartW / candles.size
        val bodyW = max(4f, step * 0.58f)
        candles.forEachIndexed { idx, c ->
            val x = left + step * idx + step / 2f
            val openY = y(c.open)
            val closeY = y(c.close)
            val highY = y(c.high)
            val lowY = y(c.low)
            val up = c.close >= c.open
            paint.color = if (up) Color.rgb(55, 190, 115) else Color.rgb(235, 85, 85)
            paint.strokeWidth = 2f
            canvas.drawLine(x, highY, x, lowY, paint)
            val topBody = min(openY, closeY)
            val bottomBody = max(openY, closeY)
            canvas.drawRect(x - bodyW / 2f, topBody, x + bodyW / 2f, max(bottomBody, topBody + 2f), paint)
        }

        currentPrice?.let { p ->
            val py = y(p)
            paint.color = Color.YELLOW
            paint.strokeWidth = 2f
            canvas.drawLine(left, py, right, py, paint)
            paint.textSize = 22f
            canvas.drawText(String.format("%.2f", p), right + 8f, py + 7f, paint)
        }

        paint.color = Color.rgb(170, 175, 185)
        paint.textSize = 20f
        canvas.drawText("Candles: ${candles.size}", left, height - 14f, paint)
    }
}
