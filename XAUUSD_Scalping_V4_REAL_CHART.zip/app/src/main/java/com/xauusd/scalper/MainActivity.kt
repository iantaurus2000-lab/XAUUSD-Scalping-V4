package com.xauusd.scalper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.View
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var api: EditText; private lateinit var token: EditText; private lateinit var chat: EditText
    private lateinit var status: TextView; private lateinit var price: TextView; private lateinit var m5: TextView; private lateinit var m1: TextView
    private lateinit var wick: TextView; private lateinit var sweep: TextView; private lateinit var bos: TextView; private lateinit var signal: TextView; private lateinit var log: TextView
    private lateinit var menuPanel: LinearLayout
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) {
        i ?: return
        val p=i.getDoubleExtra("price", Double.NaN); price.text="PRICE ${if(p.isNaN()) "--" else "%.2f".format(p)}"
        m5.text="M5 BIAS ${i.getStringExtra("bias") ?: "--"}"; m1.text="M1 SETUP ${i.getStringExtra("signal")?.substringBefore(" | Entry") ?: "WAITING"}"
        wick.text="WICK REJECTION ${i.getStringExtra("wick") ?: "WAITING"}"; sweep.text="LIQUIDITY SWEEP ${i.getStringExtra("sweep") ?: "WAITING"}"
        bos.text="BOS ${i.getStringExtra("bos") ?: "WAITING"}"; signal.text="SIGNAL: ${i.getStringExtra("signal") ?: "NO SIGNAL"}"; log.text="Log: ${i.getStringExtra("log") ?: ""}"
        if(i.getBooleanExtra("alarm", false)) toast("ENTRY SIGNAL TERDETEKSI")
    }}
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        api=findViewById(R.id.apiKey); token=findViewById(R.id.botToken); chat=findViewById(R.id.chatId); status=findViewById(R.id.status); price=findViewById(R.id.price); m5=findViewById(R.id.m5Bias); m1=findViewById(R.id.m1State); wick=findViewById(R.id.wickState); sweep=findViewById(R.id.sweepState); bos=findViewById(R.id.bosState); signal=findViewById(R.id.signal); log=findViewById(R.id.log); menuPanel=findViewById(R.id.menuPanel)
        api.setText(prefs.getString("api", "")); token.setText(prefs.getString("token", "")); chat.setText(prefs.getString("chat", ""))
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),5)
        findViewById<Button>(R.id.test).setOnClickListener { save(); testTelegram() }; findViewById<Button>(R.id.start).setOnClickListener { save(); startBot() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopService(Intent(this,SignalService::class.java)); status.text="● STOPPED" }
        findViewById<Button>(R.id.menu).setOnClickListener { toggleMenu() }
        setupMenuDialogs()
    }
    override fun onResume(){ super.onResume(); registerReceiver(receiver,IntentFilter(SignalService.ACTION),Context.RECEIVER_NOT_EXPORTED) }
    override fun onPause(){ unregisterReceiver(receiver); super.onPause() }
    private fun save(){ prefs.edit().putString("api",api.text.toString().trim()).putString("token",token.text.toString().trim()).putString("chat",chat.text.toString().trim()).apply() }
    private fun testTelegram(){ Thread { val r=Telegram.send(token.text.toString().trim(),chat.text.toString().trim(),"TEST XAUUSD Scalping Bot V4: Telegram terhubung."); runOnUiThread { log.text=if(r.first) "Log: Telegram OK" else "Log: Telegram gagal: ${r.second}" } }.start() }
    private fun startBot(){ val i=Intent(this,SignalService::class.java).apply{putExtra("api",api.text.toString().trim());putExtra("token",token.text.toString().trim());putExtra("chat",chat.text.toString().trim())}; startForegroundService(i); status.text="● RUNNING"; log.text="Log: Bot aktif • menunggu data M1/M5..." }

    private fun setupMenuDialogs(){
        findViewById<Button>(R.id.menuMarket).setOnClickListener { showMarketDialog() }
        findViewById<Button>(R.id.menuChart).setOnClickListener { showChartDialog() }
        findViewById<Button>(R.id.menuSignal).setOnClickListener { showMenuDialog("🎯 Signal", "Alur sinyal:\n\nM5 Bias → Liquidity Sweep → Wick Rejection → Wick-Tip → BOS → Confidence → Entry") }
        findViewById<Button>(R.id.menuSettings).setOnClickListener { showMenuDialog("⚙ Settings", "Pengaturan umum aplikasi.\n\nAPI Key, Telegram, notifikasi dan parameter strategi dapat diatur dari menu ini.") }
        findViewById<Button>(R.id.menuTelegram).setOnClickListener { showMenuDialog("📱 Telegram", "Telegram Bot\n\nToken dan Chat ID tersimpan secara lokal.\n\nGunakan tombol TEST TG untuk menguji koneksi.") }
        findViewById<Button>(R.id.menuApi).setOnClickListener { showMenuDialog("🔑 API", "Market Data API\n\nAPI Key digunakan untuk mengambil data XAUUSD M1/M5.\n\nKey disimpan secara lokal di perangkat.") }
        findViewById<Button>(R.id.menuStrategy).setOnClickListener { showMenuDialog("🧠 Strategy", "Strategi utama:\n\n• M5 Bias\n• Liquidity Sweep\n• Wick Rejection\n• Wick-Tip Entry\n• BOS\n• Confidence 1–5") }
        findViewById<Button>(R.id.menuRisk).setOnClickListener { showMenuDialog("💰 Risk Management", "Risk Management\n\nPengaturan SL, TP1, TP2 dan parameter risiko akan digunakan oleh mesin sinyal.\n\nBelum melakukan auto-trading.") }
        findViewById<Button>(R.id.menuHistory).setOnClickListener { showMenuDialog("📋 Signal History", "Riwayat sinyal\n\nBelum ada riwayat tersimpan pada versi ini.") }
        findViewById<Button>(R.id.menuLog).setOnClickListener { showMenuDialog("📜 Log", log.text.toString()) }
        findViewById<Button>(R.id.menuNotification).setOnClickListener { showMenuDialog("🔔 Notification", "Notifikasi sinyal:\n\nWATCH\nENTRY READY\nENTRY CONFIRMED\n\nAlarm dapat menggunakan notifikasi, suara dan getaran.") }
    }

    private fun showMarketDialog(){
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val loading = TextView(this).apply { text = "Mengambil data market..."; textSize = 18f; setTextColor(Color.WHITE); setPadding(0, 12, 0, 12) }
        box.addView(loading)
        AlertDialog.Builder(this).setTitle("📊 Market • XAU/USD").setView(box).setPositiveButton("TUTUP", null).show()
        val key = api.text.toString().trim()
        if (key.isBlank()) { loading.text = "API Key belum diisi."; return }
        Thread {
            try {
                val m1d = Market.candles(key, "1min", 20)
                val m5d = Market.candles(key, "5min", 20)
                val a = m1d.last(); val b = m5d.last()
                val msg = "Harga terakhir: %.2f\n\nM1\nOpen: %.2f\nHigh: %.2f\nLow: %.2f\nClose: %.2f\nWaktu: %s\n\nM5\nOpen: %.2f\nHigh: %.2f\nLow: %.2f\nClose: %.2f\nWaktu: %s".format(m1d.last().close, a.open,a.high,a.low,a.close,a.time,b.open,b.high,b.low,b.close,b.time)
                runOnUiThread { loading.text = msg }
            } catch(e: Exception) { runOnUiThread { loading.text = "Market error:\n${e.message}" } }
        }.start()
    }

    private fun showChartDialog(){
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chart = CandleChartView(this).apply { setBackgroundColor(Color.rgb(16,19,24)) }
        val status = TextView(this).apply { text = "Memuat M1..."; textSize = 14f; setTextColor(Color.LTGRAY); setPadding(8, 4, 8, 4) }
        val b1 = Button(this).apply { text = "M1" }; val b5 = Button(this).apply { text = "M5" }; val b15 = Button(this).apply { text = "M15" }
        buttons.addView(b1, LinearLayout.LayoutParams(0, -2, 1f)); buttons.addView(b5, LinearLayout.LayoutParams(0, -2, 1f)); buttons.addView(b15, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons); root.addView(chart, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(status)
        val dialog = AlertDialog.Builder(this).setTitle("📈 XAU/USD Chart").setView(root).setPositiveButton("TUTUP", null).create()
        dialog.show()
        val key = api.text.toString().trim()
        fun load(tf: String, interval: String){
            if(key.isBlank()){ status.text="API Key belum diisi."; return }
            status.text="Memuat $tf..."
            Thread {
                try { val data=Market.candles(key, interval, 60); runOnUiThread { chart.setData(data, tf); status.text="$tf • ${data.size} candle • realtime dari Twelve Data" } }
                catch(e:Exception){ runOnUiThread { status.text="Chart error: ${e.message}" } }
            }.start()
        }
        b1.setOnClickListener { load("M1","1min") }; b5.setOnClickListener { load("M5","5min") }; b15.setOnClickListener { load("M15","15min") }
        load("M1","1min")
    }

    private fun showMenuDialog(title:String, message:String){
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("TUTUP", null)
            .show()
    }

    private fun toggleMenu(){ menuPanel.visibility = if(menuPanel.visibility == android.view.View.VISIBLE) android.view.View.GONE else android.view.View.VISIBLE }
    private fun toast(s:String){ Toast.makeText(this,s,Toast.LENGTH_LONG).show() }
}
