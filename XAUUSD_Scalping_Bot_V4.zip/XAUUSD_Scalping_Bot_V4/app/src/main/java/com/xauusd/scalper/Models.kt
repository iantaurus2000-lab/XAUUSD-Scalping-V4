package com.xauusd.scalper

data class Candle(val time: String, val open: Double, val high: Double, val low: Double, val close: Double)
data class MarketSnapshot(val price: Double, val m1: List<Candle>, val m5: List<Candle>)
data class SignalResult(val side: String, val entry: Double, val sl: Double, val tp1: Double, val tp2: Double, val confidence: Int, val candleTime: String, val setup: String)
