package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Market {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 12000
        return try {
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            stream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun candles(apiKey: String, interval: String, outputSize: Int = 60): List<Candle> {
        val url = "https://api.twelvedata.com/time_series?symbol=XAU/USD&interval=$interval&outputsize=$outputSize&order=ASC&apikey=$apiKey"
        val text = get(url)
        val root = JSONObject(text)
        if (root.has("status") && root.optString("status") == "error") throw IllegalStateException(root.optString("message", "Twelve Data error"))
        val values = root.optJSONArray("values") ?: throw IllegalStateException("Data candle kosong")
        val out = ArrayList<Candle>()
        for (i in 0 until values.length()) {
            val x = values.getJSONObject(i)
            val o = x.optString("open").toDoubleOrNull() ?: continue
            val h = x.optString("high").toDoubleOrNull() ?: continue
            val l = x.optString("low").toDoubleOrNull() ?: continue
            val cl = x.optString("close").toDoubleOrNull() ?: continue
            out.add(Candle(x.optString("datetime"), o, h, l, cl))
        }
        if (out.size < 12) throw IllegalStateException("Candle $interval kurang dari 12")
        return out
    }

    fun snapshot(apiKey: String): MarketSnapshot {
        val m1 = candles(apiKey, "1min", 60)
        val m5 = candles(apiKey, "5min", 60)
        return MarketSnapshot(m1.last().close, m1, m5)
    }
}
