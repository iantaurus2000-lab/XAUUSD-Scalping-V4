package com.xauusd.scalper

import kotlin.math.abs

object SignalEngine {
    private fun body(c: Candle) = abs(c.close - c.open)
    private fun lowerWick(c: Candle) = minOf(c.open, c.close) - c.low
    private fun upperWick(c: Candle) = c.high - maxOf(c.open, c.close)
    private fun bullish(c: Candle) = c.close > c.open
    private fun bearish(c: Candle) = c.close < c.open

    fun bias(m5: List<Candle>): String {
        val c = m5[m5.lastIndex - 1]
        val prev = m5.subList(maxOf(0, m5.size - 21), m5.lastIndex - 1)
        val avg = prev.map { it.close }.average()
        return when { c.close > avg && c.close > c.open -> "BUY"; c.close < avg && c.close < c.open -> "SELL"; else -> "NEUTRAL" }
    }

    fun evaluate(s: MarketSnapshot): Pair<SignalResult?, Map<String,String>> {
        val m1 = s.m1
        val closed = m1[m1.lastIndex - 1]
        val sweep = m1[m1.lastIndex - 2]
        val rangeStart = maxOf(0, m1.lastIndex - 10)
        val prior = m1.subList(rangeStart, m1.lastIndex - 2)
        val priorHigh = prior.maxOf { it.high }
        val priorLow = prior.minOf { it.low }
        val b = bias(s.m5)
        val bullWick = lowerWick(sweep) >= maxOf(body(sweep) * 1.5, 0.15) && bullish(sweep)
        val bearWick = upperWick(sweep) >= maxOf(body(sweep) * 1.5, 0.15) && bearish(sweep)
        val sweepLow = sweep.low < priorLow && sweep.close > priorLow
        val sweepHigh = sweep.high > priorHigh && sweep.close < priorHigh
        val bosUp = closed.close > sweep.high
        val bosDn = closed.close < sweep.low
        val status = mutableMapOf(
            "bias" to b,
            "wick" to if (bullWick || bearWick) "CONFIRMED" else "WAITING",
            "sweep" to if (sweepLow || sweepHigh) "CONFIRMED" else "WAITING",
            "bos" to if (bosUp || bosDn) "CONFIRMED" else "WAITING",
            "m1" to closed.time
        )
        val buy = b == "BUY" && bullWick && sweepLow && bosUp
        val sell = b == "SELL" && bearWick && sweepHigh && bosDn
        if (!buy && !sell) return null to status
        val side = if (buy) "BUY" else "SELL"
        val entry = s.price
        val rawSl = if (buy) sweep.low else sweep.high
        val risk = maxOf(abs(entry - rawSl), 0.30)
        val sl = if (buy) entry - risk else entry + risk
        val tp1 = if (buy) entry + risk else entry - risk
        val tp2 = if (buy) entry + risk * 1.8 else entry - risk * 1.8
        val result = SignalResult(side, entry, sl, tp1, tp2, 5, closed.time, "Liquidity Sweep + Wick Rejection + BOS")
        return result to status
    }
}
