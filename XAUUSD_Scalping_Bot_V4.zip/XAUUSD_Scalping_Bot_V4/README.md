# XAUUSD Scalping V4

V4 basis from V3 with persistent settings, V4 dashboard/menu, Telegram test, alarm flag, and release signing support.

## GitHub
1. Upload all project files to a repository.
2. Keep repository private if possible.
3. Create Actions secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.
4. Run Actions > Build XAUUSD V4 > Run workflow.
5. Download artifact XAUUSD-Scalping-V4-APK.

applicationId: com.xauusd.scalper
versionCode: 4
versionName: 4.0
