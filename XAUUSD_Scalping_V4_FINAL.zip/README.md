# XAUUSD Scalping V4 PRO

Signal-only Android app for XAU/USD.

## Main screen
- MT5-inspired quotes + live price card
- M1 / M5 / M15 candlestick chart
- live price line
- EMA20 / EMA50 overlay
- Support / Resistance
- Fibonacci 23.6 / 38.2 / 50 / 61.8 / 78.6
- BUY / SELL / WAIT signal lamp
- Wick-tip entry level
- Liquidity sweep + wick rejection + BOS status
- Entry / SL / TP1 / TP2 / confidence

## Data
Uses Twelve Data REST endpoints for XAU/USD. Price refresh is periodic and candle refresh follows timeframe data. It is not a broker-native tick feed like MetaTrader 5; broker-native realtime can be added later if a broker/API feed is provided.

## Trading
No auto-trading. The app only generates and sends signals.


V4.2 stability fix: CandleChartView now has the XML-compatible Context/AttributeSet constructor; receiver lifecycle is guarded.
