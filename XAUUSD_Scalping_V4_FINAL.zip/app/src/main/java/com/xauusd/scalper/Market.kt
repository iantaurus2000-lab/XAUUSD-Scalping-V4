package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale

object Market {
    private const val SYMBOL = "XAU/USD"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.requestMethod = "GET"
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code: ${extractMessage(body)}")
            }
            body
        } finally { c.disconnect() }
    }

    private fun extractMessage(body: String): String {
        return try {
            val j = JSONObject(body)
            j.optString("message").ifBlank { j.optString("code").ifBlank { body.take(180) } }
        } catch (_: Exception) { body.take(180) }
    }

    private fun requestUrl(interval: String, outputSize: Int): String {
        val symbol = URLEncoder.encode(SYMBOL, "UTF-8")
        return String.format(
            Locale.US,
            "https://api.twelvedata.com/time_series?symbol=%s&interval=%s&outputsize=%d&order=ASC&apikey=",
            symbol, interval, outputSize
        )
    }

    private fun candlesFromJson(text: String, interval: String): List<Candle> {
        val root = JSONObject(text)
        val status = root.optString("status")
        if (status.equals("error", true) || root.has("code")) {
            throw IllegalStateException("Twelve Data: ${extractMessage(text)}")
        }
        val values = root.optJSONArray("values")
            ?: throw IllegalStateException("Twelve Data tidak mengembalikan candle $interval. Cek API key dan akses data XAU/USD.")
        val out = ArrayList<Candle>(values.length())
        for (i in 0 until values.length()) {
            val x = values.optJSONObject(i) ?: continue
            val o = x.optString("open").toDoubleOrNull() ?: continue
            val h = x.optString("high").toDoubleOrNull() ?: continue
            val l = x.optString("low").toDoubleOrNull() ?: continue
            val cl = x.optString("close").toDoubleOrNull() ?: continue
            out.add(Candle(x.optString("datetime"), o, h, l, cl))
        }
        if (out.isEmpty()) throw IllegalStateException("Candle $interval kosong.")
        return out
    }

    private fun aggregate(source: List<Candle>, minutes: Int): List<Candle> {
        if (minutes == 1) return source
        val out = ArrayList<Candle>()
        var bucket: String? = null
        var first: Candle? = null
        var last: Candle? = null
        var high = Double.NEGATIVE_INFINITY
        var low = Double.POSITIVE_INFINITY
        for (c in source) {
            val key = try {
                val parts = c.time.split(" ", ":")
                val hour = parts.getOrNull(parts.size - 2)?.toIntOrNull() ?: 0
                val minute = parts.getOrNull(parts.size - 1)?.toIntOrNull() ?: 0
                "${c.time.take(11)}${String.format(Locale.US, "%02d:%02d", hour, (minute / minutes) * minutes)}"
            } catch (_: Exception) { c.time }
            if (bucket != key) {
                if (first != null && last != null) out.add(Candle(bucket ?: last.time, first.open, high, low, last.close))
                bucket = key
                first = c
                high = c.high
                low = c.low
            } else {
                high = maxOf(high, c.high)
                low = minOf(low, c.low)
            }
            last = c
        }
        if (first != null && last != null) out.add(Candle(bucket ?: last.time, first.open, high, low, last.close))
        return out
    }

    fun livePrice(apiKey: String): Double {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        val symbol = URLEncoder.encode(SYMBOL, "UTF-8")
        val key = URLEncoder.encode(apiKey, "UTF-8")
        val url = "https://api.twelvedata.com/price?symbol=$symbol&apikey=$key"
        val root = JSONObject(get(url))
        if (root.has("code") || root.optString("status").equals("error", true)) {
            throw IllegalStateException("Twelve Data: ${extractMessage(root.toString())}")
        }
        return root.optString("price").toDoubleOrNull()
            ?: throw IllegalStateException("Harga live XAU/USD tidak tersedia")
    }

    fun price(apiKey: String): Double {
        val candles = candles(apiKey, "1min", 5)
        return candles.lastOrNull()?.close ?: throw IllegalStateException("Harga XAU/USD tidak tersedia")
    }

    fun candles(apiKey: String, interval: String, outputSize: Int = 120): List<Candle> {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        val size = if (interval == "1min") maxOf(outputSize, 500) else outputSize
        val url = requestUrl(interval, size) + URLEncoder.encode(apiKey, "UTF-8")
        return candlesFromJson(get(url), interval)
    }

    fun snapshot(apiKey: String, previousPrice: Double = Double.NaN): MarketSnapshot {
        // One API request for M1; M5 and M15 are built locally. This greatly reduces API calls/rate-limit errors.
        val m1 = candles(apiKey, "1min", 500)
        val m5 = aggregate(m1, 5)
        val m15 = aggregate(m1, 15)
        if (m1.size < 20) throw IllegalStateException("Data M1 terlalu sedikit: ${m1.size} candle")
        val live = m1.last().close
        return MarketSnapshot(live, m1.takeLast(300), m5.takeLast(120), m15.takeLast(80), if (previousPrice.isNaN()) live else previousPrice)
    }
}
