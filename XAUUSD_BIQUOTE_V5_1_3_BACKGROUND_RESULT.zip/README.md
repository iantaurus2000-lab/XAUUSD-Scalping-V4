# XAUUSD BIQUOTE V5.1.3 BACKGROUND RESULT

Signal-only XAUUSD scalper using BIQUOTE realtime data.

Improvements:
- Chart has a wider right-side safety margin so the last candle is not cramped.
- Background foreground-service alarm uses a new HIGH notification channel.
- START can request Android battery-optimization exemption for background reliability.
- Signal history records WIN / LOSS / PENDING.
- History shows win rate, average win R, and average loss R.
- Outcome is evaluated from subsequent M1 candles: TP2 hit = WIN, SL hit = LOSS; if both are touched in the same candle, it is conservatively counted as LOSS.
