package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

object Market {
    private const val BASE = "https://biquote.io/api"
    private const val SYMBOL = "XAUUSD"
    private val displayTime = DateTimeFormatter.ofPattern("MM-dd HH:mm:ss", Locale.US).withZone(ZoneOffset.UTC)

    data class Quote(
        val price: Double,
        val bid: Double,
        val ask: Double,
        val spread: Double,
        val dayHigh: Double,
        val dayLow: Double,
        val changePercent: Double,
        val marketState: String,
        val stale: Boolean,
        val quoteAgeSeconds: Double
    )

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.requestMethod = "GET"
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("biquote HTTP $code: ${message(body)}")
            body
        } finally { c.disconnect() }
    }

    private fun message(body: String): String {
        return try {
            val j = JSONObject(body)
            j.optString("message").ifBlank { j.optString("error").ifBlank { body.take(180) } }
        } catch (_: Exception) { body.take(180) }
    }

    fun quote(): Quote {
        val j = JSONObject(get("$BASE/$SYMBOL"))
        val price = j.optDouble("mid", Double.NaN)
        if (price.isNaN() || price <= 0.0) throw IllegalStateException("biquote: harga XAUUSD tidak tersedia")
        return Quote(
            price = price,
            bid = j.optDouble("bid", price),
            ask = j.optDouble("ask", price),
            spread = j.optDouble("spread", 0.0),
            dayHigh = j.optDouble("high", Double.NaN),
            dayLow = j.optDouble("low", Double.NaN),
            changePercent = j.optDouble("dayDiffPercent", Double.NaN),
            marketState = j.optString("marketState", "unknown"),
            stale = j.optBoolean("stale", false),
            quoteAgeSeconds = j.optDouble("quoteAgeSeconds", 0.0)
        )
    }

    private fun candles(interval: String, limit: Int): List<Candle> {
        val j = JSONObject(get("$BASE/$SYMBOL/ohlc?interval=$interval&limit=$limit"))
        val bars = j.optJSONArray("bars") ?: throw IllegalStateException("biquote: candle $interval tidak tersedia")
        val out = ArrayList<Candle>(bars.length())
        for (i in 0 until bars.length()) {
            val b = bars.optJSONObject(i) ?: continue
            val o = b.optDouble("open", Double.NaN)
            val h = b.optDouble("high", Double.NaN)
            val l = b.optDouble("low", Double.NaN)
            val c = b.optDouble("close", Double.NaN)
            if (o.isNaN() || h.isNaN() || l.isNaN() || c.isNaN()) continue
            val rawTime = b.optString("openTime")
            val time = try { displayTime.format(Instant.parse(rawTime)) } catch (_: Exception) { rawTime }
            out.add(Candle(time, o, h, l, c))
        }
        if (out.isEmpty()) throw IllegalStateException("biquote: candle $interval kosong")
        return out.asReversed()
    }

    fun snapshot(previousPrice: Double = Double.NaN): MarketSnapshot {
        val m1 = candles("1m", 500)
        val m5 = candles("5m", 120)
        val m15 = candles("15m", 80)
        if (m1.size < 50) throw IllegalStateException("biquote: data M1 terlalu sedikit (${m1.size})")
        val q = quote()
        return MarketSnapshot(
            price = q.price,
            m1 = m1.takeLast(300),
            m5 = m5.takeLast(120),
            m15 = m15.takeLast(80),
            previousPrice = if (previousPrice.isNaN()) q.price else previousPrice,
            dayHigh = q.dayHigh,
            dayLow = q.dayLow,
            spread = q.spread,
            dayChangePercent = q.changePercent,
            marketState = q.marketState,
            stale = q.stale,
            quoteAgeSeconds = q.quoteAgeSeconds
        )
    }

    fun livePrice(): Double = quote().price
}
