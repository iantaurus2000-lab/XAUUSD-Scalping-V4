package com.xauusd.scalper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

object TradeHistory {
    private const val KEY = "trade_history_v1"
    private const val MAX = 100

    private fun load(context: Context): JSONArray {
        return try { JSONArray(context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]") }
        catch (_: Exception) { JSONArray() }
    }

    private fun save(context: Context, a: JSONArray) {
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun addPending(context: Context, s: SignalResult) {
        val a = load(context)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("key") == "${s.side}|${s.candleTime}") return
        }
        val o = JSONObject()
            .put("key", "${s.side}|${s.candleTime}")
            .put("side", s.side)
            .put("entry", s.entry)
            .put("sl", s.sl)
            .put("tp1", s.tp1)
            .put("tp2", s.tp2)
            .put("confidence", s.confidence)
            .put("time", s.candleTime)
            .put("setup", s.setup)
            .put("result", "PENDING")
            .put("r", 0.0)
        a.put(0, o)
        while (a.length() > MAX) a.remove(a.length() - 1)
        save(context, a)
    }

    fun resolve(context: Context, candles: List<Candle>) {
        if (candles.isEmpty()) return
        val a = load(context)
        var changed = false
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("result") != "PENDING") continue
            val signalTime = o.optString("time")
            val start = candles.indexOfFirst { it.time == signalTime }
            if (start < 0 || start >= candles.lastIndex) continue
            val side = o.optString("side")
            val entry = o.optDouble("entry")
            val sl = o.optDouble("sl")
            val tp2 = o.optDouble("tp2")
            var result: String? = null
            for (j in start + 1 until candles.size) {
                val c = candles[j]
                result = if (side == "BUY") {
                    when {
                        c.low <= sl && c.high >= tp2 -> "LOSS"
                        c.low <= sl -> "LOSS"
                        c.high >= tp2 -> "WIN"
                        else -> null
                    }
                } else {
                    when {
                        c.high >= sl && c.low <= tp2 -> "LOSS"
                        c.high >= sl -> "LOSS"
                        c.low <= tp2 -> "WIN"
                        else -> null
                    }
                }
                if (result != null) break
            }
            if (result != null) {
                val risk = abs(entry - sl).coerceAtLeast(0.00001)
                val reward = abs(tp2 - entry)
                val r = if (result == "WIN") reward / risk else -1.0
                o.put("result", result).put("r", r)
                changed = true
            }
        }
        if (changed) save(context, a)
    }

    fun summary(context: Context): String {
        val a = load(context)
        var wins = 0; var losses = 0; var pending = 0; var winR = 0.0; var lossR = 0.0
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            when (o.optString("result")) {
                "WIN" -> { wins++; winR += o.optDouble("r") }
                "LOSS" -> { losses++; lossR += o.optDouble("r") }
                else -> pending++
            }
        }
        val closed = wins + losses
        val rate = if (closed == 0) 0.0 else wins * 100.0 / closed
        val avgWin = if (wins == 0) 0.0 else winR / wins
        val avgLoss = if (losses == 0) 0.0 else lossR / losses
        return "ENTRY RESULT • Total ${a.length()} • WIN $wins • LOSS $losses • PENDING $pending • Win Rate %.1f%% • Avg Win +%.2fR • Avg Loss %.2fR".format(rate, avgWin, avgLoss)
    }

    fun text(context: Context): String {
        val a = load(context)
        if (a.length() == 0) return "Belum ada entry."
        val sb = StringBuilder()
        sb.append(summary(context)).append("\n\n")
        for (i in 0 until minOf(a.length(), 30)) {
            val o = a.optJSONObject(i) ?: continue
            sb.append(if (i == 0) "" else "\n---\n")
            sb.append(o.optString("result")).append(" • ").append(o.optString("side"))
            sb.append("\nEntry ").append("%.2f".format(o.optDouble("entry")))
            sb.append(" • SL ").append("%.2f".format(o.optDouble("sl")))
            sb.append(" • TP2 ").append("%.2f".format(o.optDouble("tp2")))
            sb.append("\n").append(o.optString("time"))
            if (o.optString("result") != "PENDING") sb.append(" • ").append("%.2fR".format(o.optDouble("r")))
        }
        return sb.toString()
    }

    fun clear(context: Context) = save(context, JSONArray())
}
