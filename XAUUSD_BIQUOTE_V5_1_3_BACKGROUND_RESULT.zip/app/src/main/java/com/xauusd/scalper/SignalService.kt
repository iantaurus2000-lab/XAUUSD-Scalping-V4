package com.xauusd.scalper

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.*

class SignalService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var token = ""
    private var chat = ""
    private var lastSignalKey = ""

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        token = intent?.getStringExtra("token")?.takeIf { it.isNotBlank() } ?: prefs.getString("token", "") ?: ""
        chat = intent?.getStringExtra("chat")?.takeIf { it.isNotBlank() } ?: prefs.getString("chat", "") ?: ""
        createChannels()
        startForeground(7, foregroundNotification("XAUUSD BIQUOTE • background signal engine aktif"))
        scope.coroutineContext.cancelChildren()
        scope.launch {
            while (isActive) {
                try {
                    val s = Market.snapshot()
                    TradeHistory.resolve(this@SignalService, s.m1)
                    val (signal, status) = SignalEngine.evaluate(s)
                    sendUpdate(s, signal, status, null)
                    if (signal != null) {
                        val key = signal.side + "|" + signal.candleTime
                        if (key != lastSignalKey) {
                            TradeHistory.addPending(this@SignalService, signal)
                            fireSignalAlarm(signal)
                            if (token.isNotBlank() && chat.isNotBlank()) {
                                val ok = Telegram.send(token, chat, formatSignal(signal)).first
                                sendUpdate(s, signal, status, if (ok) "SIGNAL + TELEGRAM OK" else "SIGNAL OK • TELEGRAM GAGAL")
                            } else {
                                sendUpdate(s, signal, status, "SIGNAL OK • Telegram belum dikonfigurasi")
                            }
                            lastSignalKey = key
                        }
                    }
                } catch (e: Exception) {
                    sendUpdate(null, null, emptyMap(), "DATA ERROR: ${e.message}")
                }
                delay(10_000)
            }
        }
        return START_STICKY
    }

    private fun sendUpdate(s: MarketSnapshot?, sig: SignalResult?, st: Map<String, String>, error: String?) {
        val i = Intent(ACTION).setPackage(packageName)
        if (s != null) i.putExtra("price", s.price)
        i.putExtra("bias", st["bias"] ?: "WAITING")
        i.putExtra("wick", st["wick"] ?: "WAITING")
        i.putExtra("sweep", st["sweep"] ?: "WAITING")
        i.putExtra("bos", st["bos"] ?: "WAITING")
        i.putExtra("signal", sig?.let { "${it.side} | Entry ${"%.2f".format(it.entry)} | SL ${"%.2f".format(it.sl)} | TP1 ${"%.2f".format(it.tp1)} | TP2 ${"%.2f".format(it.tp2)}" } ?: "NO SIGNAL")
        i.putExtra("result", TradeHistory.summary(this))
        i.putExtra("log", error ?: "BIQUOTE OK • M1/M5/M15 diperbarui")
        sendBroadcast(i)
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("xau_v2", "XAUUSD Background Service", NotificationManager.IMPORTANCE_LOW))
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val soundOn = prefs.getBoolean("sound", true)
        val vibrationOn = prefs.getBoolean("vibration", true)
        val ch = NotificationChannel("signal_alerts_v3", "XAUUSD BUY SELL Alerts", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Alarm BUY/SELL XAUUSD"
        ch.enableVibration(vibrationOn)
        if (soundOn) ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_HIGH).build()) else ch.setSound(null, null)
        nm.createNotificationChannel(ch)
    }

    private fun fireSignalAlarm(s: SignalResult) {
        if (Build.VERSION.SDK_INT >= 33 && !NotificationManagerCompat.from(this).areNotificationsEnabled()) return
        val title = if (s.side == "BUY") "🟢 XAUUSD BUY" else "🔴 XAUUSD SELL"
        val text = "Entry %.2f • SL %.2f • TP1 %.2f • TP2 %.2f • %d/5".format(s.entry, s.sl, s.tp1, s.tp2, s.confidence)
        val n = NotificationCompat.Builder(this, "signal_alerts_v3")
            .setSmallIcon(R.drawable.ic_xau_logo)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n${s.setup}\n${s.reason}"))
            .setAutoCancel(true)
            .setOngoing(false)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % 100000).toInt(), n)
    }

    private fun foregroundNotification(t: String) = NotificationCompat.Builder(this, "xau_v2")
        .setContentTitle("XAUUSD BIQUOTE SCALPER")
        .setContentText(t)
        .setSmallIcon(R.drawable.ic_xau_logo)
        .setOngoing(true)
        .build()

    private fun formatSignal(s: SignalResult) = "🟢 XAUUSD SCALPING\n\n${s.side}\nEntry: ${"%.2f".format(s.entry)}\nSL: ${"%.2f".format(s.sl)}\nTP1: ${"%.2f".format(s.tp1)}\nTP2: ${"%.2f".format(s.tp2)}\n\nTF: M1\nBias: M5 ${s.side}\nSetup: ${s.setup}\nConfidence: ${s.confidence}/5"

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION = "com.xauusd.scalper.MARKET_UPDATE" }
}
