package com.xauusd.scalper

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class CandleChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private var candles: List<Candle> = emptyList()
    private var timeframe = "M1"
    private var currentPrice: Double? = null
    private var signal: SignalResult? = null
    private var showEma = true
    private var showLevels = true
    private var showFib = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dragX = 0f
    private var offset = 0

    fun setData(data: List<Candle>, tf: String, livePrice: Double? = null, sig: SignalResult? = null) {
        candles = data.takeLast(240)
        timeframe = tf
        currentPrice = livePrice ?: candles.lastOrNull()?.close
        signal = sig
        offset = offset.coerceIn(0, max(0, candles.size - 25))
        invalidate()
    }

    fun setCurrentPrice(p: Double?) { currentPrice = p; invalidate() }
    fun setLayers(ema: Boolean, levels: Boolean, fib: Boolean) { showEma = ema; showLevels = levels; showFib = fib; invalidate() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dragX = e.x; return true }
            MotionEvent.ACTION_MOVE -> {
                val d = e.x - dragX
                if (abs(d) > 8f) {
                    offset += if (d > 0) -2 else 2
                    offset = offset.coerceIn(0, max(0, candles.size - 25))
                    dragX = e.x
                    invalidate()
                }
                return true
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(8, 11, 16))
        if (candles.isEmpty()) {
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 17f
            paint.color = Color.LTGRAY
            canvas.drawText("WAITING FOR MARKET DATA", 24f, height / 2f, paint)
            return
        }

        val visibleCount = min(70, candles.size)
        val end = candles.size - offset
        val start = max(0, end - visibleCount)
        val visible = candles.subList(start, end)
        if (visible.isEmpty()) return

        val left = 18f
        val right = width - 104f
        val top = 52f
        val bottom = height - 42f
        val w = max(1f, right - left)
        val h = max(1f, bottom - top)

        val ind = IndicatorEngine.snapshot(candles)
        val rawHigh = max(visible.maxOf { it.high }, currentPrice ?: visible.last().high)
        val rawLow = min(visible.minOf { it.low }, currentPrice ?: visible.last().low)
        val baseRange = max(rawHigh - rawLow, 0.5)
        val pad = baseRange * .08
        val maxP = rawHigh + pad
        val minP = rawLow - pad
        val range = maxP - minP
        fun y(p: Double) = (bottom - ((p - minP) / range * h)).toFloat()

        // Header
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 18f
        paint.color = Color.WHITE
        canvas.drawText("XAU/USD", left, 24f, paint)
        paint.textSize = 12f
        paint.color = Color.rgb(135, 148, 165)
        canvas.drawText("$timeframe  •  LIVE", left + 90f, 24f, paint)
        paint.typeface = Typeface.DEFAULT

        // Grid + price scale
        paint.strokeWidth = 1f
        paint.textSize = 10f
        for (i in 0..6) {
            val gy = top + h * i / 6f
            paint.color = Color.rgb(31, 37, 47)
            canvas.drawLine(left, gy, right, gy, paint)
            paint.color = Color.rgb(135, 145, 158)
            canvas.drawText("%.2f".format(maxP - range * i / 6), right + 5f, gy + 4f, paint)
        }

        // Time separators
        val step = w / visible.size
        for (i in visible.indices) {
            if (i % max(1, visible.size / 6) == 0) {
                paint.color = Color.rgb(26, 31, 39)
                canvas.drawLine(left + i * step, top, left + i * step, bottom, paint)
                paint.color = Color.rgb(100, 110, 125)
                paint.textSize = 9f
                canvas.drawText(visible[i].time.takeLast(5), left + i * step + 2f, bottom + 14f, paint)
            }
        }

        // Candles
        val bodyWidth = max(2.5f, min(11f, step * .62f))
        visible.forEachIndexed { i, c ->
            val x = left + step * i + step / 2f
            val up = c.close >= c.open
            val candleColor = if (up) Color.rgb(38, 202, 132) else Color.rgb(238, 82, 95)
            paint.color = candleColor
            paint.strokeWidth = max(1.2f, step * .12f)
            canvas.drawLine(x, y(c.high), x, y(c.low), paint)
            paint.style = Paint.Style.FILL
            val topBody = y(max(c.open, c.close))
            val botBody = y(min(c.open, c.close))
            canvas.drawRect(x - bodyWidth / 2f, topBody, x + bodyWidth / 2f, max(botBody, topBody + 2f), paint)
        }

        fun line(vals: List<Double>, color: Int, widthPx: Float = 1.8f) {
            paint.color = color
            paint.strokeWidth = widthPx
            paint.style = Paint.Style.STROKE
            var prev: PointF? = null
            vals.forEachIndexed { i, v ->
                if (!v.isNaN() && i in visible.indices) {
                    val p = PointF(left + step * i + step / 2f, y(v))
                    if (prev != null) canvas.drawLine(prev!!.x, prev!!.y, p.x, p.y, paint)
                    prev = p
                }
            }
            paint.style = Paint.Style.FILL
        }

        if (showEma) {
            val closes = visible.map { it.close }
            line(IndicatorEngine.ema(closes, 20), Color.rgb(255, 193, 7), 2f)
            line(IndicatorEngine.ema(closes, 50), Color.rgb(70, 160, 245), 2f)
        }

        if (showLevels) {
            paint.strokeWidth = 1.4f
            paint.color = Color.rgb(70, 160, 245)
            canvas.drawLine(left, y(ind.support), right, y(ind.support), paint)
            paint.color = Color.rgb(240, 90, 100)
            canvas.drawLine(left, y(ind.resistance), right, y(ind.resistance), paint)
            paint.textSize = 9f
            paint.color = Color.rgb(100, 175, 240)
            canvas.drawText("S %.2f".format(ind.support), left + 4f, y(ind.support) - 4f, paint)
            paint.color = Color.rgb(245, 105, 115)
            canvas.drawText("R %.2f".format(ind.resistance), left + 4f, y(ind.resistance) - 4f, paint)
        }

        if (showFib) {
            val fibs = listOf(
                "23.6" to ind.fib236, "38.2" to ind.fib382, "50.0" to ind.fib50,
                "61.8" to ind.fib618, "78.6" to ind.fib786
            )
            paint.color = Color.rgb(130, 135, 150)
            paint.strokeWidth = 1f
            paint.textSize = 8f
            fibs.forEach { (label, value) ->
                canvas.drawLine(left, y(value), right, y(value), paint)
                canvas.drawText(label, right - 28f, y(value) - 3f, paint)
            }
        }

        // Live price line and tag
        currentPrice?.let { p ->
            val py = y(p)
            paint.color = Color.WHITE
            paint.strokeWidth = 1.6f
            canvas.drawLine(left, py, right, py, paint)
            paint.color = Color.rgb(235, 235, 235)
            canvas.drawRect(right + 3f, py - 11f, right + 82f, py + 11f, paint)
            paint.color = Color.rgb(15, 18, 23)
            paint.textSize = 10f
            canvas.drawText("%.2f".format(p), right + 8f, py + 4f, paint)
        }

        // Signal levels: entry, SL, TP1, TP2 and wick-tip marker
        signal?.let { s ->
            val c = if (s.side == "BUY") Color.rgb(0, 230, 135) else Color.rgb(255, 72, 88)
            paint.color = c
            paint.strokeWidth = 2.2f
            canvas.drawLine(left, y(s.entry), right, y(s.entry), paint)
            paint.textSize = 10f
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("${s.side} ${s.state}", left + 5f, y(s.entry) - 6f, paint)
            paint.typeface = Typeface.DEFAULT
            paint.strokeWidth = 1f
            paint.color = Color.rgb(255, 145, 70)
            canvas.drawLine(left, y(s.sl), right, y(s.sl), paint)
            paint.color = Color.rgb(70, 210, 145)
            canvas.drawLine(left, y(s.tp1), right, y(s.tp1), paint)
            paint.color = Color.rgb(100, 175, 245)
            canvas.drawLine(left, y(s.tp2), right, y(s.tp2), paint)
        }

        // Legend
        paint.textSize = 9f
        paint.color = Color.rgb(255, 193, 7); canvas.drawText("EMA20", left, height - 16f, paint)
        paint.color = Color.rgb(70, 160, 245); canvas.drawText("EMA50", left + 48f, height - 16f, paint)
        paint.color = Color.rgb(110, 120, 135); canvas.drawText("S/R", left + 98f, height - 16f, paint)
        if (showFib) canvas.drawText("FIB", left + 132f, height - 16f, paint)
    }
}
