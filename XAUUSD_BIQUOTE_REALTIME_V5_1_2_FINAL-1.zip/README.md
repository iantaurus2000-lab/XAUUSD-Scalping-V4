# XAUUSD BIQUOTE SCALPER V5.1.2

Signal-only Android app for XAUUSD using BIQUOTE market data.

- Realtime XAUUSD quote
- M1 / M5 / M15 candles
- M5 bias
- Liquidity sweep + wick rejection + BOS
- Wick-tip entry reference
- Telegram signal delivery
- Foreground service for background scanning
- Local BUY/SELL notification alarm
- Chart with right-side price scale and visible latest candle
- No auto trading

Build with GitHub Actions workflow: `XAUUSD BIQUOTE REALTIME V5.1.2`.
