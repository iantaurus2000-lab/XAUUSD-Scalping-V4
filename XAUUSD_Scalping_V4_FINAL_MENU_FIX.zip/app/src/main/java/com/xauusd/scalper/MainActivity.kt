package com.xauusd.scalper

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var api: EditText; private lateinit var token: EditText; private lateinit var chat: EditText
    private lateinit var status: TextView; private lateinit var price: TextView; private lateinit var m5: TextView; private lateinit var m1: TextView
    private lateinit var wick: TextView; private lateinit var sweep: TextView; private lateinit var bos: TextView; private lateinit var signal: TextView; private lateinit var log: TextView
    private lateinit var menuPanel: LinearLayout
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) {
        i ?: return
        val p=i.getDoubleExtra("price", Double.NaN); price.text="PRICE ${if(p.isNaN()) "--" else "%.2f".format(p)}"
        m5.text="M5 BIAS ${i.getStringExtra("bias") ?: "--"}"; m1.text="M1 SETUP ${i.getStringExtra("signal")?.substringBefore(" | Entry") ?: "WAITING"}"
        wick.text="WICK REJECTION ${i.getStringExtra("wick") ?: "WAITING"}"; sweep.text="LIQUIDITY SWEEP ${i.getStringExtra("sweep") ?: "WAITING"}"
        bos.text="BOS ${i.getStringExtra("bos") ?: "WAITING"}"; signal.text="SIGNAL: ${i.getStringExtra("signal") ?: "NO SIGNAL"}"; log.text="Log: ${i.getStringExtra("log") ?: ""}"
        if(i.getBooleanExtra("alarm", false)) toast("ENTRY SIGNAL TERDETEKSI")
    }}
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        api=findViewById(R.id.apiKey); token=findViewById(R.id.botToken); chat=findViewById(R.id.chatId); status=findViewById(R.id.status); price=findViewById(R.id.price); m5=findViewById(R.id.m5Bias); m1=findViewById(R.id.m1State); wick=findViewById(R.id.wickState); sweep=findViewById(R.id.sweepState); bos=findViewById(R.id.bosState); signal=findViewById(R.id.signal); log=findViewById(R.id.log); menuPanel=findViewById(R.id.menuPanel)
        api.setText(prefs.getString("api", "")); token.setText(prefs.getString("token", "")); chat.setText(prefs.getString("chat", ""))
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),5)
        findViewById<Button>(R.id.test).setOnClickListener { save(); testTelegram() }; findViewById<Button>(R.id.start).setOnClickListener { save(); startBot() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopService(Intent(this,SignalService::class.java)); status.text="● STOPPED" }
        findViewById<Button>(R.id.menu).setOnClickListener { toggleMenu() }
    }
    override fun onResume(){ super.onResume(); registerReceiver(receiver,IntentFilter(SignalService.ACTION),Context.RECEIVER_NOT_EXPORTED) }
    override fun onPause(){ unregisterReceiver(receiver); super.onPause() }
    private fun save(){ prefs.edit().putString("api",api.text.toString().trim()).putString("token",token.text.toString().trim()).putString("chat",chat.text.toString().trim()).apply() }
    private fun testTelegram(){ Thread { val r=Telegram.send(token.text.toString().trim(),chat.text.toString().trim(),"TEST XAUUSD Scalping Bot V4: Telegram terhubung."); runOnUiThread { log.text=if(r.first) "Log: Telegram OK" else "Log: Telegram gagal: ${r.second}" } }.start() }
    private fun startBot(){ val i=Intent(this,SignalService::class.java).apply{putExtra("api",api.text.toString().trim());putExtra("token",token.text.toString().trim());putExtra("chat",chat.text.toString().trim())}; startForegroundService(i); status.text="● RUNNING"; log.text="Log: Bot aktif • menunggu data M1/M5..." }
    private fun toggleMenu(){ menuPanel.visibility = if(menuPanel.visibility == android.view.View.VISIBLE) android.view.View.GONE else android.view.View.VISIBLE }
    private fun toast(s:String){ Toast.makeText(this,s,Toast.LENGTH_LONG).show() }
}
