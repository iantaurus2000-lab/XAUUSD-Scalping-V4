# XAUUSD BIQUOTE SCALPER V5

Android signal-only XAUUSD scalping app.

## Market data
- Provider: biquote.io
- Symbol: XAUUSD
- No API key
- No Twelve Data credits
- Live quote uses `mid`
- Candles: M1 / M5 / M15
- Indicators: EMA20 / EMA50 / Support / Resistance / Fibonacci
- Signal logic: M5 bias → liquidity sweep → wick rejection → BOS → wick-tip entry → confidence
- No auto trading

## GitHub Actions
Workflow file:
`.github/workflows/build-biquote-realtime.yml`

Workflow name:
`XAUUSD BIQUOTE REALTIME`

Artifact:
`XAUUSD-BIQUOTE-REALTIME-APK`


## V5.1
- Foreground signal service continues when screen is off.
- Local BUY/SELL high-priority notification with sound/vibration.
- Telegram failure no longer disables local alarm.
- Signal scan every 10 seconds.
- Chart reserves right-side price scale so the latest candle remains visible.
