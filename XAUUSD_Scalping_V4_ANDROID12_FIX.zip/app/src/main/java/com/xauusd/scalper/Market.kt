package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Market {
    private const val SYMBOL = "XAU/USD"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.requestMethod = "GET"
        return try {
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            stream?.bufferedReader()?.use { it.readText() } ?: throw IllegalStateException("Empty response (${c.responseCode})")
        } finally { c.disconnect() }
    }

    fun price(apiKey: String): Double {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        val text = get("https://api.twelvedata.com/price?symbol=$SYMBOL&apikey=$apiKey&dp=3")
        val root = JSONObject(text)
        if (root.has("code") || root.optString("status") == "error") {
            throw IllegalStateException(root.optString("message", "Twelve Data error"))
        }
        return root.optString("price").toDoubleOrNull() ?: throw IllegalStateException("Harga XAU/USD tidak tersedia")
    }

    fun candles(apiKey: String, interval: String, outputSize: Int = 120): List<Candle> {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        val url = "https://api.twelvedata.com/time_series?symbol=$SYMBOL&interval=$interval&outputsize=$outputSize&order=ASC&apikey=$apiKey"
        val root = JSONObject(get(url))
        if (root.has("code") || root.optString("status") == "error") {
            throw IllegalStateException(root.optString("message", "Twelve Data error"))
        }
        val values = root.optJSONArray("values") ?: throw IllegalStateException("Data candle $interval kosong")
        val out = ArrayList<Candle>()
        for (i in 0 until values.length()) {
            val x = values.getJSONObject(i)
            val o = x.optString("open").toDoubleOrNull() ?: continue
            val h = x.optString("high").toDoubleOrNull() ?: continue
            val l = x.optString("low").toDoubleOrNull() ?: continue
            val cl = x.optString("close").toDoubleOrNull() ?: continue
            out.add(Candle(x.optString("datetime"), o, h, l, cl))
        }
        if (out.size < 60) throw IllegalStateException("Candle $interval kurang dari 60")
        return out
    }

    fun snapshot(apiKey: String, previousPrice: Double = Double.NaN): MarketSnapshot {
        val m1 = candles(apiKey, "1min", 120)
        val m5 = candles(apiKey, "5min", 120)
        val m15 = candles(apiKey, "15min", 120)
        val live = price(apiKey)
        return MarketSnapshot(live, m1, m5, m15, if (previousPrice.isNaN()) live else previousPrice)
    }
}
